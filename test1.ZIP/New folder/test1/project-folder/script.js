// script.js - Puzzle Game với hint box bên trái và lưới ô

const TOTAL = 16;
const COLS = 4;
const ROWS = 4;
const IMAGE_FOLDER = "images/";

const boardEl = document.getElementById("board");
const piecesGrid = document.getElementById("piecesGrid");
const preview = document.getElementById("preview");
const startBtn = document.getElementById("startBtn");
const shuffleBtn = document.getElementById("shuffleBtn");
const winBox = document.getElementById("winMessage");
const playAgainBtn = document.getElementById("playAgainBtn");

let state = {
  tiles: {},
  placedCount: 0,
  dragging: null
};

function getBoardDimensions(){
  const s = getComputedStyle(document.documentElement);
  const bw = parseFloat(s.getPropertyValue("--board-w"));
  const bh = parseFloat(s.getPropertyValue("--board-h"));
  const cw = bw / COLS;
  const ch = bh / ROWS;
  return { bw, bh, cw, ch };
}

// tạo ô lưới và overlay slot
function createCells(){
  boardEl.innerHTML = "";
  const { cw, ch } = getBoardDimensions();
  for (let r=0;r<ROWS;r++){
    for (let c=0;c<COLS;c++){
      const idx = r*COLS + c;

      // invisible cell
      const div = document.createElement("div");
      div.className = "cell";
      div.dataset.index = idx;
      div.style.left = (c*cw)+"px";
      div.style.top = (r*ch)+"px";
      div.style.width = cw+"px";
      div.style.height = ch+"px";
      boardEl.appendChild(div);

      // slot overlay
      const slot = document.createElement("div");
      slot.className = "slot-overlay";
      slot.style.left = div.style.left;
      slot.style.top = div.style.top;
      slot.style.width = div.style.width;
      slot.style.height = div.style.height;
      boardEl.appendChild(slot);
    }
  }
}

// tạo thumbnail trong panel
function populateFrame(order){
  piecesGrid.innerHTML = "";
  state.tiles = {};
  const { cw, ch } = getBoardDimensions();

  for (const idx of order){
    const d = document.createElement("div");
    d.className = "thumb";
    d.dataset.idx = idx;
    d.style.backgroundImage = `url("${IMAGE_FOLDER}${idx}.png")`;
    d.style.width = cw+"px";
    d.style.height = ch+"px";
    d.addEventListener("pointerdown", onPointerDown);
    piecesGrid.appendChild(d);
    state.tiles[idx] = { placed:false, el:d };
  }
}

function shuffleArray(a){
  const b = a.slice();
  for (let i=b.length-1;i>0;i--){
    const j = Math.floor(Math.random()*(i+1));
    [b[i], b[j]] = [b[j], b[i]];
  }
  return b;
}

function showPreviewAndStart(){
  preview.classList.remove("hidden");
  preview.style.opacity = "1";
  setTimeout(()=>{
    preview.style.transition = "opacity .1s linear";
    preview.style.opacity = "0";
    setTimeout(()=>{
      preview.classList.add("hidden");
      preview.style.transition = "";
      startRound();
    },100);
  },1000);
}

function startRound(){
  state.placedCount = 0;
  winBox.classList.add("hidden");
  boardEl.querySelectorAll(".placed-piece").forEach(n=>n.remove());
  createCells();
  const order = shuffleArray([...Array(TOTAL)].map((_,i)=>i));
  populateFrame(order);
}

// DRAG & DROP
function onPointerDown(e){
  e.preventDefault();
  const thumb = e.currentTarget;
  const idx = Number(thumb.dataset.idx);

  const clone = document.createElement("div");
  clone.className = "dragging";
  clone.style.backgroundImage = thumb.style.backgroundImage;
  clone.style.width = thumb.style.width;
  clone.style.height = thumb.style.height;
  document.body.appendChild(clone);

  state.dragging = { idx, sourceEl:thumb, clone };
  moveClone(e.clientX, e.clientY);

  document.addEventListener("pointermove", onPointerMove);
  document.addEventListener("pointerup", onPointerUp);
}
function onPointerMove(e){ moveClone(e.clientX, e.clientY); }
function moveClone(x,y){
  if (!state.dragging) return;
  const c = state.dragging.clone;
  c.style.left = x+"px";
  c.style.top = y+"px";
}
function onPointerUp(e){
  finishDrag(e.clientX, e.clientY);
  document.removeEventListener("pointermove", onPointerMove);
  document.removeEventListener("pointerup", onPointerUp);
}
function finishDrag(x,y){
  if (!state.dragging) return;
  const { idx, sourceEl, clone } = state.dragging;
  const rect = boardEl.getBoundingClientRect();
  const inside = x>=rect.left && x<=rect.right && y>=rect.top && y<=rect.bottom;

  const { cw, ch } = getBoardDimensions();
  const col = idx % COLS;
  const row = Math.floor(idx / COLS);
  const cx = rect.left + col*cw + cw/2;
  const cy = rect.top + row*ch + ch/2;

  const dist = Math.hypot(x-cx, y-cy);
  const threshold = Math.hypot(cw,ch)*0.5;

  if (inside && dist <= threshold && !boardEl.querySelector(`.placed-piece[data-idx="${idx}"]`)){
    snapPiece(idx, sourceEl);
  } else {
    piecesGrid.appendChild(sourceEl);
  }
  clone.remove();
  state.dragging = null;
}

function snapPiece(idx, sourceEl){
  const { cw, ch } = getBoardDimensions();
  const col = idx % COLS;
  const row = Math.floor(idx/COLS);

  const img = document.createElement("img");
  img.className = "placed-piece";
  img.dataset.idx = idx;
  img.src = `${IMAGE_FOLDER}${idx}.png`;
  img.style.left = (col*cw)+"px";
  img.style.top = (row*ch)+"px";
  img.style.width = cw+"px";
  img.style.height = ch+"px";
  boardEl.appendChild(img);

  sourceEl.remove();
  state.placedCount++;
  if(state.placedCount === TOTAL) showWin();
}

function showWin(){ winBox.classList.remove("hidden"); }
playAgainBtn.addEventListener("click", ()=> startRound());
startBtn.addEventListener("click", ()=> showPreviewAndStart());
shuffleBtn.addEventListener("click", ()=> startRound());

// INIT
window.addEventListener("load", ()=>{
  createCells();
  populateFrame(shuffleArray([...Array(TOTAL)].map((_,i)=>i)));
});
